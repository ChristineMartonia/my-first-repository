import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class PetChecker{
    public static void main(String[] args) throws PetException {
        List<Pet> Pets = new ArrayList<Pet>();
        try (Scanner s = new Scanner(System.in)) {
            while (true) {
                System.out.println("##*******************************************##");
                System.out.println("##                PET CHECKER                ##");
                System.out.println("##===========================================##");
                System.out.println("##                                           ##");
                System.out.println("##          Press 1 : To Add  Pet            ##");
                System.out.println("##          Press 2 : To Remove Pet          ##");
                System.out.println("##          Press 3 : To Display Pet         ##");
                System.out.println("##          Press 1 : To Exit portal         ##");
                System.out.println("##                                           ##");
                System.out.println("##===========================================##");
                System.out.print("\n Choose Action to take: ");
                char choice = s.next().toLowerCase().charAt(0);
                switch (choice) {
                    case '1':

                        System.out.println("Enter Pet's name: ");
                        String pet = s.next().toUpperCase();
                        if (hero.length() < 2) {
                            throw new UniverseException(
                                    "As old as the multiverse aged there is no avenger named with only 2 letters.Please try again!");

                        } else {
                            System.out.println("What powers does the hero have?");
                            String power = s.next();
                            System.out.println("From what universe the hero comes from?(Our universe is 616):");
                            int uni = s.nextInt();
                            if (uni < 0) {
                                throw new UniverseException(
                                        "A negative universe is impossible! it means it cease to exist!");
                            } else {
                                Avenger newAvenger = new Avenger(hero, power, uni);
                                Avengers.add(newAvenger);
                                System.out.println(hero + " has joined the avengers!");
                                break;
                            }

                        }

                    case 'b':
                        System.out.println("Who will retire in the avengers?");
                        String retiree = s.next().toUpperCase();
                        if (!Avengers.contains(retiree)) {
                            System.out.println("Error! There is no avenger with that name! Please try again!");
                            break;
                        }
                        int index = Avengers.indexOf(retiree);
                        System.out.println(retiree + " has been removed from the avenger roster.");
                        Avengers.remove(index + 1);
                        break;
                    case 'c':
                        for (int i = 0; i < Avengers.size(); i++) {
                            Avengers.get(i).Introduction();
                            System.out.println(
                                    "Alert! There is an invasion in another universes. Do you want the avenger to verse-jump to another universe?(y/n)");
                            char jump = s.next().toLowerCase().charAt(0);
                            if (jump == 'y') {
                                System.out.println("In what universe the Avenger is needed?");
                                int universe = s.nextInt();
                                if (universe < 0) {
                                    System.out.println(
                                            "A negative universe is impossible! it means it cease to exist! Please try again!");
                                    break;
                                }
                                Avengers.get(i).versejump(universe);
                                System.out.println(
                                        Avengers.get(i).getName() + " has traveled to "
                                                + Avengers.get(i).getUniverse());
                            } else {
                                System.out.println(Avengers.get(i).getName() + " chooses to stay at universe \n"
                                        + Avengers.get(i).getUniverse());
                            }

                        }
                        break;
                    case 'x':
                        System.out.println("Program terminated.Goodbye!");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("\nInvalid choice! Please try Again.\n");
                        continue;
                }
            }
        }

    }
}