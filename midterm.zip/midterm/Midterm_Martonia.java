/******************** Christine Martonia ************************/

import java.util.*;
import java.io.*;


/*************************** MENU OF this app ****************************/

class MainMenu
{
  public void menu()
  {
    System.out.println("##*******************************************##");
    System.out.println("##                PET CHECKER                ##");
    System.out.println("##===========================================##");
    System.out.println("##                                           ##");
    System.out.println("##          Press 1 : To Add  Pet            ##");
    System.out.println("##          Press 2 : To Remove Pet          ##");
    System.out.println("##          Press 3 : To Display Pet         ##");
    System.out.println("##          Press 1 : To Exit portal         ##");
    System.out.println("##                                           ##");
    System.out.println("##===========================================##");

  }
}

/************************ To add details of a pet *********************/

class Pet_Add
{
    public void createFile()
    {
        Scanner sc=new Scanner(System.in);

        PetDetail petD=new PetDetail();
        petD.getInfo();
        
        try{
            File f1=new File("file"+petD.pet_name+".txt");
            if(f1.createNewFile()){
                FileWriter myWriter = new FileWriter("file"+petD.pet_kind+".txt");
                myWriter.write("Pet Name:"+petD.pet_name+"\n"+
                "Pet Kind     :"+petD.pet_kind+"\n"+"Pet Color  :"+petD.pet_color);
                myWriter.close();
                System.out.println("\nWelcome " +petD.pet_name+ ". A cute " +petD.pet_kind+". I like your "+petD.pet_color+ " colored skin! Let's check your " +petD.pet_concern);

                System.out.print("\nPress Enter to Continue...");
                sc.nextLine();
            }
            else {
                System.out.println("\nInvalid input :(");
                System.out.print("\nPress Enter to Continue...");
                sc.nextLine();
            }
        }
        catch(Exception e){System.out.println(e);}
    }
}
/************************* Taking pet Details ************************/

class PetDetail
{
    public String pet_color;
    public String pet_kind;
    public String pet_name;
    public String pet_concern;
    String name;
    String kind;
    String color;
    String concern;
    public void getInfo()
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter Pet name --------: ");
        sc.nextLine();
        pet_name = sc.nextLine();
        System.out.print("Pet is a (dog,cat,etc.)? -: ");
        pet_kind = sc.nextLine();
        System.out.print("Enter Pet  color ----------: ");
        pet_color = sc.nextLine();
        System.out.print("Enter Pet concern (eyes, nose, arm..) ----------: ");
        pet_color = sc.nextLine();
    }
}

/************************  display details of a pet  *********************/

class Pet_Display
{
  public void viewFile(String s) throws Exception
  {
    File file = new File("file"+s+".txt");
    Scanner sc = new Scanner(file);

    while (sc.hasNextLine())
     {
       System.out.println(sc.nextLine());
     }
   }
}

/***************************** To Remove Pet *************************/

class Employee_Remove
{
    public void removeFile(String ID)
    {

    File file = new File("file"+ID+".txt");
      if(file.exists())
       {
         if(file.delete());
         {
           System.out.println("\nEmployee has been removed Successfully");
         }
       }
      else
       {
            System.out.println("\nEmployee does not exists :( ");
       }
     }
}

/************************ To Update details of Employee ********************/

class Employee_Update
{
  public void updateFile(String s,String o,String n) throws IOException
  {
   File file = new File("file"+s+".txt");
   Scanner sc = new Scanner(file);
   String fileContext="";
   while (sc.hasNextLine())
       {
         fileContext =fileContext+"\n"+sc.nextLine();
       }
   FileWriter myWriter = new FileWriter("file"+s+".txt");
   fileContext = fileContext.replaceAll(o,n);
   myWriter.write(fileContext);
   myWriter.close();

  }
}


/************************ To Exit from the Pet Checker Portal *********************/

class CodeExit
{
  public void out()
  {
    System.out.println("\n*****************************************");
    System.out.println("$ cat Thank You For Using my Software :) ");
    System.out.println("*****************************************");
    System.out.println("\t\t/~ <0d3d by Abhinav Dubey\n");
    System.exit(0);
  }
}


/***************************** Main Class *******************************/
class EmployManagementSystem
{
  public static void main(String arv[])
  {
    /** To clear the output Screen **/
    System.out.print("\033[H\033[2J");

    Scanner sc=new Scanner(System.in);
    Pet_Display epv =new Pet_Display();

    int i=0;

    /*** Callining Mainmenu Class function ****/
    MainMenu obj1 = new MainMenu();
    obj1.menu();

    /*** Initialising loop for Menu Choices ***/
    while(i<6)
    {

      System.out.print("\nPlease Enter choice :");
      i=Integer.parseInt(sc.nextLine());

      /** Switch Case Statements **/
      switch(i)
      {
        case 1:
        {
        /** Creating class's object and calling Function using that object **/
        Employee_Add ep =new Employee_Add();
        ep.createFile();

        System.out.print("\033[H\033[2J");
        obj1.menu();
        break;
        }
        case 2:
        {
          System.out.print("\nPlease Enter Employee's ID :");
          String s=sc.nextLine();
          try
          {
            epv.viewFile(s);}
            catch(Exception e){System.out.println(e);}


            System.out.print("\nPress Enter to Continue...");
            sc.nextLine();
            System.out.print("\033[H\033[2J");
            obj1.menu();
            break;
          }

        case 3:
        {
          System.out.print("\nPlease Enter Employee's ID :");
          String s=sc.nextLine();
          Employee_Remove epr =new Employee_Remove();
          epr.removeFile(s);

          System.out.print("\nPress Enter to Continue...");
          sc.nextLine();
          System.out.print("\033[H\033[2J");
          obj1.menu();
          break;
        }
        case 4:
        {
            System.out.print("\nPlease Enter Employee's ID :");
            String I=sc.nextLine();
            try
            {
              epv.viewFile(I);
            }
            catch(Exception e)
            {
              System.out.println(e);
            }
            Employee_Update epu = new Employee_Update();
            System.out.print("Please Enter the detail you want to Update :");
    	      System.out.print("\nFor Example :\n");
            System.out.println("If you want to Change the Name, then Enter Current Name and Press Enter. Then write the new Name then Press Enter. It will Update the Name.\n");
            String s=sc.nextLine();
            System.out.print("Please Enter the Updated Info :");
            String n=sc.nextLine();
            try
            {
              epu.updateFile(I,s,n);

              System.out.print("\nPress Enter to Continue...");
              sc.nextLine();
              System.out.print("\033[H\033[2J");
              obj1.menu();
              break;
            }
            catch(IOException e)
            {
              System.out.println(e);
            }
        }
        case 5:
        {
          CodeExit obj = new CodeExit();
          obj.out();
        }
      }
    }
  }
}