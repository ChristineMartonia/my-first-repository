public class CustomException extends Exception  
{  
    // class that uses custom exception MyCustomException  
public CustomException(String message) 
{  
        super (message);   
        System.out.println("Caught the exception");  

}  
}  
    
