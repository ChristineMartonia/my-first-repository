import java.util.*;

public class Main {

  public static void main(String[] args) throws NumException {
    ArrayList list = new ArrayList();
    int length;
    int count = 0;

    ArrayList list2 = new ArrayList();
    ArrayList list3 = new ArrayList();
    ArrayList<CustomArray> listing = new ArrayList<CustomArray>();
    CustomArray list1 = new CustomArray();
    Scanner sc = new Scanner(System.in);

    boolean mainLoop = true;

    while (mainLoop) {
      // list1.add(45);
      // list1.add(1);
      // list1.add(2);
      System.out.println("Topics to Write: \n");

      list.add("1. Travel \n");
      list.add("2. Food \n");
      list.add("3. Lovelife \n");
      list.add("4. Family \n");
      list.add("5. View Notes\n");
      list.add("6. Logout \n");
      for (int i = 0; i < 6; i++) {
        System.out.println(list.get(i));
      }

      System.out.println("Enter Choice:");
      int choice = sc.nextInt();

      switch (choice) {
        case 1:
          do {
            list2.add("Lorenfe Cuadero");
            list2.add("October 19, 2022");
            list2.add("Been busy working on with my midterm exam.");
            try {
              System.out.println("Wanting to travel?\n");
              System.out.println("Please enter your name:\n");
              sc.nextLine();
              String answer = sc.nextLine();

              try {
                length = answer.length();
                for (int i = 0; i < length; i++) {
                  if (
                    !Character.isDigit(answer.charAt(i)) &&
                    !Character.isLetter(answer.charAt(i)) &&
                    !Character.isWhitespace(answer.charAt(i))
                  ) {
                    count++;
                    throw new NameException(
                      "              -->   Error Input!  <--"
                    );
                  }
                }
              } catch (NameException e) {
                e.errorName();
              }
              list2.add(answer);
              try {
                System.out.println("Please enter date:\n");
                String date = sc.nextLine();
                list2.add(date);
                System.out.println("Destination: \n");
                String destination = sc.nextLine();
                list2.add(destination);
                System.out.println("Notes Preview: \n");
                for (int i = 0; i < list2.size(); i++) {
                  System.out.println(list2.get(i));
                }

                Boolean thirdLoop = true;
                while (thirdLoop) {
                  System.out.println("What you want to do next:");
                  list3.add("1. Add \n");
                  list3.add("2. Remove \n");
                  list3.add("3. Display \n");
                  list3.add("4. Clear \n");
                  list3.add("5. Exit \n");
                  for (int index = 0; index < list3.size(); index++) {
                    System.out.println(list3.get(index).toString());
                  }

                  int key = sc.nextInt();

                  switch (key) {
                    case 1:
                      System.out.println("Add your Notes here: \n");
                      String note = sc.nextLine();
                      list2.add(note);
                      break;
                    case 2:
                      System.out.println("Remove Notes here: \n");
                      for (int i = 0; i < list2.size(); i++) {
                        System.out.println(list2.get(i));
                      }
                      int removes = sc.nextInt();
                      list2.remove(list2.get(removes));
                      System.out.println("Removed a Note! \n");

                      break;
                    case 3:
                      System.out.println("Notes Preview: \n");
                      for (int i = 0; i < list2.size(); i++) {
                        System.out.println(list2.get(i));
                      }
                      break;
                    case 4:
                      System.out.println("Clear Notes: \n");
                      list2.clear();
                      System.out.println(" Succesfully Cleared All! \n");

                      break;
                    case 5:
                      System.out.println("Exiting.. \n");
                      System.exit(1);
                      break;
                    default:
                      break;
                  }
                }
              } catch (Exception e) {}
            } catch (Exception e) {
              // TODO: handle exception
            }
            break;
          } while (true);
        case 2:
          do {
            list2.add("Lorenfe Cuadero");
            list2.add("October 19, 2022");
            list2.add("Been busy working on with my midterm exam.");
            try {
              System.out.println("Cravings\n");
              System.out.println("Enter identity:\n");
              sc.nextLine();
              String answer = sc.nextLine();

              try {
                length = answer.length();
                for (int i = 0; i < length; i++) {
                  if (
                    !Character.isDigit(answer.charAt(i)) &&
                    !Character.isLetter(answer.charAt(i)) &&
                    !Character.isWhitespace(answer.charAt(i))
                  ) {
                    count++;
                    throw new NameException(
                      "              -->   Error Input!  <--"
                    );
                  }
                }
              } catch (NameException e) {
                e.errorName();
              }
              list2.add(answer);
              try {
                System.out.println("Date:\n");
                String date = sc.nextLine();
                list2.add(date);
                System.out.println("Food Cravings: \n");
                String destination = sc.nextLine();
                list2.add(destination);
                System.out.println("Notes Preview: \n");
                for (int i = 0; i < list2.size(); i++) {
                  System.out.println(list2.get(i));
                }
              } catch (Exception e) {}
            } catch (Exception e) {
              // TODO: handle exception
            }
            break;
          } while (true);
        case 3:
          do {
            list2.add("Lorenfe Cuadero");
            list2.add("October 19, 2022");
            list2.add("Been busy working on with my midterm exam.");
            try {
              System.out.println("Lovelife Status\n");
              System.out.println("Enter identity:\n");
              sc.nextLine();
              String answer = sc.nextLine();

              try {
                length = answer.length();
                for (int i = 0; i < length; i++) {
                  if (
                    !Character.isDigit(answer.charAt(i)) &&
                    !Character.isLetter(answer.charAt(i)) &&
                    !Character.isWhitespace(answer.charAt(i))
                  ) {
                    count++;
                    throw new NameException(
                      "              -->   Error Input!  <--"
                    );
                  }
                }
              } catch (NameException e) {
                e.errorName();
              }
              list2.add(answer);
              try {
                System.out.println("Date:\n");
                String date = sc.nextLine();
                list2.add(date);
                System.out.println("Lovelife Status Description: \n");
                String destination = sc.nextLine();
                list2.add(destination);
                System.out.println("Notes Preview: \n");
                for (int i = 0; i < list2.size(); i++) {
                  System.out.println(list2.get(i));
                }
              } catch (Exception e) {}
            } catch (Exception e) {
              // TODO: handle exception
            }
            break;
          } while (true);
        case 4:
          do {
            list2.add("Lorenfe Cuadero");
            list2.add("October 19, 2022");
            list2.add("Been busy working on with my midterm exam.");
            try {
              System.out.println("Family is Love\n");
              System.out.println("Enter identity:\n");
              sc.nextLine();
              String answer = sc.nextLine();

              try {
                length = answer.length();
                for (int i = 0; i < length; i++) {
                  if (
                    !Character.isDigit(answer.charAt(i)) &&
                    !Character.isLetter(answer.charAt(i)) &&
                    !Character.isWhitespace(answer.charAt(i))
                  ) {
                    count++;
                    throw new NameException(
                      "              -->   Error Input!  <--"
                    );
                  }
                }
              } catch (NameException e) {
                e.errorName();
              }
              list2.add(answer);
              try {
                System.out.println("Date:\n");
                String date = sc.nextLine();
                list2.add(date);
                System.out.println("Family Bond Description: \n");
                String destination = sc.nextLine();
                list2.add(destination);
                System.out.println("Notes Preview: \n");
                for (int i = 0; i < list2.size(); i++) {
                  System.out.println(list2.get(i));
                }
              } catch (Exception e) {}
            } catch (Exception e) {
              // TODO: handle exception               break;

            }
            break;
          } while (true);
        case 5:
          if (list2 != null) {
            for (int i = 0; i < list2.size(); i++) {
              System.out.println(list2.get(i).toString());
              break;
            }
          }
          if (list2 == null) {
            System.out.println("You do not have notes yet.");
          }

          break;
        case 6:
          System.out.println(
            "================================================================"
          );
          System.out.println("                 ---->  Exiting Program  <----");
          System.out.println(
            "================================================================"
          );
          break;
        default:
          if (choice < 1 || choice > 6) {
            try {
              throw new NumException("  ---->  Invalid Input!  <---- ");
            } catch (NumException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
            }
          }
          if (choice != Integer.MAX_VALUE) {
            try {
                System.out.println("InputMismatchException: ");

            } catch (InputMismatchException e) {
               System.out.println("InputMismatchException: " + e.getMessage());
            }
          }
      }
    }
  }
}
