import java.lang.reflect.Array;
import java.util.Arrays;

public class CustomArray{
    public int[] data;
    public static int defaultSize = 10;
    public int size = 0;
    public String travel;
    public String destination;
    public String name;
    public int age;

    
public CustomArray() {
        data = new int[defaultSize];
        System.out.println("  =================================================================");
        System.out.println("                    WELCOME TO LC's Simple ENote");
        System.out.println("  =================================================================");
    }

    public void add(int destination2) {
        if (isFull()) {
            resize();
        }
        data[size++] = destination2;
    }

    public void resize() {
        int[] temp = new int[data.length * 2];
        for (int i = 0; i < data.length; i++) {
            temp[i] = data[i];
        }
        data = temp;
    }

    public boolean isFull() {
        return size == data.length;
    }

    public int remove() {
        int removed = data[--size];
        return removed;
    }

    public int get(int index) {
        return data[index];
    }

    public int size() {
        return size;
    }

    public void set(int index, int value) {
        data[index] = value;
    }

    public String toString() {
        return "Main{" + "data = " + Arrays.toString(data) + ", size = " + size + '}';
    }
    public String getTravel(){
        return travel;

    }
    public void setTravel(String travel){
        this.travel = travel;
    }
    public String getDestination(){
        return destination;
    }
    public void setDestination(String destination){
        this.destination = destination; 
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public int getAge(){
        return age;
    }
    public void setAge(int age){
        this.age = age;
    }
}